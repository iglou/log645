LOG645 - LAB1

1 - Répertoire sec
En ligne de commande, se placer dans le répertoire sec, effectuer un ~make.
Exécuter un ~./run.sh ou ~./tp1 2 3 3 ou les paramètres correspondent au numéro du problème, à la valeur initiale de la matrice et au nombre d'itérations.

2 - Répertoire par
En ligne de commande, se placer dans le répertoire par, effectuer un ~make.
Exécuter un ~./run.sh ou mpirun ~--hostfile hostfile -np 9 tp1 2 3 5 ou les paramètres correspondent au numéro du problème, à la valeur initiale de la matrice et au nombre d'itérations.
