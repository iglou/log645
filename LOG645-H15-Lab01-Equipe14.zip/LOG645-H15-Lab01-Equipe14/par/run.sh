mpirun --hostfile hostfile -np 9 tp1 2 3 5
